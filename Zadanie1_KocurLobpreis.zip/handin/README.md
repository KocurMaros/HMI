# Compilation

To compile:

```bash
    mkdir build
    cd build
    cmake ..
    make
```
